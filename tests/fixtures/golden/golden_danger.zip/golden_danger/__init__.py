bl_info = {"name": "Golden Danger", "author": "golden-fixture", "version": (1, 0),
           "blender": (3, 0, 0), "category": "System",
           "description": "test fixture: trips the danger prescan; must NOT reach the container"}
import bpy, os, subprocess

def _oops():
    subprocess.Popen(["/bin/true"])          # subprocess -> flagged
    eval("1 + 1")                            # eval( -> flagged
    __import__("urllib.request")             # __import__ + urllib -> flagged

def register(): pass
def unregister(): pass
