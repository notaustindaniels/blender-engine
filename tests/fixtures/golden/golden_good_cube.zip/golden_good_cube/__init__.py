bl_info = {"name": "Golden Good Cube", "author": "golden-fixture", "version": (1, 0, 0),
           "blender": (3, 0, 0), "category": "Add Mesh",
           "description": "test fixture: registers a headless-drivable generator"}
import bpy, bmesh

class GOLDEN_OT_make_cube(bpy.types.Operator):
    bl_idname = "object.golden_make_cube"
    bl_label = "Golden Make Cube"
    def execute(self, context):
        me = bpy.data.meshes.new("golden_cube")
        bm = bmesh.new(); bmesh.ops.create_cube(bm, size=2.0); bm.to_mesh(me); bm.free()
        ob = bpy.data.objects.new("golden_cube", me)
        context.collection.objects.link(ob)
        return {"FINISHED"}

def register(): bpy.utils.register_class(GOLDEN_OT_make_cube)
def unregister(): bpy.utils.unregister_class(GOLDEN_OT_make_cube)
