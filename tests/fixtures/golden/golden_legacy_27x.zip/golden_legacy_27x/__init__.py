bl_info = {"name": "Golden Legacy 27x", "author": "golden-fixture", "version": (0, 1),
           "blender": (2, 7, 9), "category": "Mesh",
           "description": "test fixture: pre-2.8 API, must not enable on 2.8+"}
import bpy

def register():
    bpy.utils.register_module(__name__)     # AttributeError on Blender 2.8+

def unregister():
    bpy.utils.unregister_module(__name__)
