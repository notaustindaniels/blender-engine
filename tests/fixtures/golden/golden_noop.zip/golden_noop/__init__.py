bl_info = {"name": "Golden Noop", "author": "golden-fixture", "version": (1, 0),
           "blender": (3, 0, 0), "category": "Object",
           "description": "test fixture: enables and registers but generates nothing"}
import bpy

class GOLDEN_OT_noop(bpy.types.Operator):
    bl_idname = "object.golden_noop"
    bl_label = "Golden Noop"
    def execute(self, context):
        return {"FINISHED"}   # deliberately no geometry delta

def register(): bpy.utils.register_class(GOLDEN_OT_noop)
def unregister(): bpy.utils.unregister_class(GOLDEN_OT_noop)
